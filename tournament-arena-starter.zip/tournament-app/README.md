# Tournament Arena — Starter

Mobile-first skill tournament web app prototype.

Included: Login/Signup UI, 3 tournament tiers (৳20/৳50/৳100), 100-player target, 50% prize-pool rule, wallet demo, Color Rush game, leaderboard/profile UI.

IMPORTANT: This starter does NOT process real money. For production, add a secure backend/database, authentication, server-authoritative scoring, tournament locking, wallet ledger, payment/withdrawal provider, KYC/age/fraud controls, admin panel, and legal/compliance review.
